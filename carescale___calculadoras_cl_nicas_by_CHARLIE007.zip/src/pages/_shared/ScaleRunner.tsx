
```typescript
/* @tweakable Sticky nav height used for bottom controls */
import { useMemo, useState } from "react";
import { ScaleDefinition } from "../../scales/definitions";
import { ScaleStepSingle, ScaleStepMulti } from "../../components/ScaleStep";

export default function ScaleRunner({ def }: { def: ScaleDefinition }) {
  const [stepIdx, setStepIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number | number[]>>( {});

  const step = def.steps[stepIdx];
  const progress = ((stepIdx + 1) / def.steps.length) * 100;

  const total = useMemo(() => def.computeTotal(answers), [answers, def]);
  const classification = def.classify(total);

  function setSingle(key: string, score: number) {
    setAnswers((prev) => ({ ...prev, [key]: score }));
  }

  function toggleMulti(stepKey: string, optKey: string, score: number) {
    setAnswers((prev) => {
      const arr = new Set((prev[stepKey] as number[])?.map(Number) ?? []);
      if (arr.has(score)) arr.delete(score); else arr.add(score);
      return { ...prev, [stepKey]: Array.from(arr) };
    });
  }

  const canNext = stepIdx < def.steps.length - 1;
  const canPrev = stepIdx > 0;

  return (
    <div className="space-y-6">
      {/* Hero */}
      {stepIdx === 0 && def.hero && (
        <div className="rounded-2xl p-6 bg-gradient-to-br from-sky-50 to-emerald-50 dark:from-slate-800 dark:to-slate-900 ring-1 ring-slate-200/60 dark:ring-slate-700/60">
          <h1 className="text-3xl font-semibold tracking-tight mb-1">{def.title}</h1>
          <p className="text-slate-600 dark:text-slate-300">{def.hero}</p>
        </div>
      )}

      {/* Progress */}
      <div className="h-2 rounded-full bg-slate-200/70 dark:bg-slate-800 overflow-hidden">
        <div className="h-full bg-gradient-to-r from-sky-400 to-emerald-400" style={{ width: `${progress}%` }} />
      </div>

      {/* Step */}
      <div>
        {step.kind === "single" ? (
          <ScaleStepSingle
            stepTitle={step.title}
            stepDesc={step.desc}
            options={step.options.map((o) => ({ key: o.key, title: o.title, desc: o.desc, score: o.score, icon: o.icon }))}
            value={String(answers[step.key] ?? "")}
            onChange={(optKey) => {
              const selected = step.options.find((o) => o.key === optKey)!;
              setSingle(step.key, selected.score);
            }}
          />
        ) : (
          <ScaleStepMulti
            stepTitle={step.title}
            stepDesc={step.desc}
            options={step.options.map((o) => ({ key: o.key, title: o.title, desc: o.desc, score: o.score, icon: o.icon }))}
            values={new Set(((answers[step.key] as number[]) ?? []).map(Number))}
            onToggle={(optKey) => {
              const selected = step.options.find((o) => o.key === optKey)!;
              toggleMulti(step.key, optKey, selected.score);
            }}
          />
        )}
      </div>

      {/* Nav */}
      <div className="sticky bottom-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md py-3 border-t border-slate-200/60 dark:border-slate-800 flex items-center justify-between gap-3">
        <button
          className="px-4 h-10 rounded-xl text-slate-700 dark:text-slate-300 ring-1 ring-slate-300/70 dark:ring-slate-700 disabled:opacity-50"
          onClick={() => setStepIdx((i) => Math.max(0, i - 1))}
          disabled={!canPrev}
        >
          Anterior
        </button>
        <div className="text-sm text-slate-500 dark:text-slate-400">Total provisional: <span className="font-semibold">{total}</span></div>
        <button
          className="px-5 h-10 rounded-xl text-white bg-gradient-to-r from-sky-500 to-emerald-500 shadow-lg disabled:opacity-50"
          onClick={() => setStepIdx((i) => Math.min(def.steps.length - 1, i + 1))}
          disabled={!canNext}
        >
          Siguiente
        </button>
      </div>

      {/* Resultado final */}
      {!canNext && (
        <div className="rounded-2xl p-6 bg-white/70 dark:bg-slate-900/60 backdrop-blur-md ring-1 ring-slate-200/60 dark:ring-slate-700/60 shadow-xl">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-semibold">Resultado</h3>
              <p className="text-slate-600 dark:text-slate-300">Puntaje total y categoría estimada.</p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold">{total}</div>
              <div className="text-sm" style={{ color: classification.color }}>{classification.label}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}