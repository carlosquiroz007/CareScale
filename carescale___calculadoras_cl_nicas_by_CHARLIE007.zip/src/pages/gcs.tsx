
```tsx
import ScaleRunner from "./_shared/ScaleRunner";
import { GCSDef } from "../scales/definitions";
/* @tweakable Page padding for gcs */
export default function GCSPage(){ return <div className="max-w-5xl mx-auto p-6"><ScaleRunner def={GCSDef}/></div>; }