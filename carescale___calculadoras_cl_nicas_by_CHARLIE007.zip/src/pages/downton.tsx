
```typescript
import ScaleRunner from "./_shared/ScaleRunner";
import { DowntonDef } from "../scales/definitions";
/* @tweakable Page padding for downton */
export default function DowntonPage(){ return <div className="max-w-5xl mx-auto p-6"><ScaleRunner def={DowntonDef}/></div>; }