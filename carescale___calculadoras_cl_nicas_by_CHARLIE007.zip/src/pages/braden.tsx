
```tsx
import ScaleRunner from "./_shared/ScaleRunner";
import { BradenDef } from "../scales/definitions";
/* @tweakable Page padding for braden */
export default function BradenPage(){ return <div className="max-w-5xl mx-auto p-6"><ScaleRunner def={BradenDef}/></div>; }