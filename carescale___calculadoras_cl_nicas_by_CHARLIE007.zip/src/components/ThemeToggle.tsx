/* @tweakable Label shown on the theme toggle button */
const TOGGLE_LABEL = "Modo oscuro";

/* @tweakable Tailwind-ish classes applied to the toggle button (string) */
const TOGGLE_BTN_CLASS =
  "flex items-center gap-2 px-3 h-9 rounded-full ring-1 ring-slate-300/70 dark:ring-slate-700 bg-white/80 dark:bg-slate-900/70 backdrop-blur-md shadow-sm hover:shadow transition-all text-slate-700 dark:text-slate-200";

/* @tweakable Icon size classes for the Sun/Moon icons */
const ICON_SIZE_CLASS = "h-4 w-4";

import React from "react";
import { useTheme } from "../theme/ThemeProvider";
import { Moon, Sun } from "lucide-react";

export default function ThemeToggle() {
  const { theme, toggle } = useTheme();

  return (
    <button
      onClick={toggle}
      className={TOGGLE_BTN_CLASS}
      aria-label="Cambiar tema"
      title="Cambiar tema"
      type="button"
    >
      {theme === "dark" ? <Sun className={ICON_SIZE_CLASS} /> : <Moon className={ICON_SIZE_CLASS} />}
      <span className="text-sm">{TOGGLE_LABEL}</span>
    </button>
  );
}