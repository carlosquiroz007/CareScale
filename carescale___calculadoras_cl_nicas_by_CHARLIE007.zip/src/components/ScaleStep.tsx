
```typescript
/* @tweakable Grid columns & motion timing for steps */
import { OptionCard } from "../components/OptionCard";
import { motion } from "framer-motion";
import { ReactNode } from "react";

export type SingleOption = { key: string; title: string; desc?: string; score: number; icon?: ReactNode };
export type MultiOption = { key: string; title: string; desc?: string; score: number; icon?: ReactNode };

export function ScaleStepSingle({
  stepTitle,
  stepDesc,
  options,
  value,
  onChange,
}: {
  stepTitle: ReactNode;
  stepDesc?: ReactNode;
  options: SingleOption[];
  value?: string; // key seleccionada
  onChange: (key: string) => void;
}) {
  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-2xl font-semibold tracking-tight">{stepTitle}</h2>
        {stepDesc && <p className="text-slate-600 dark:text-slate-300">{stepDesc}</p>}
      </div>

      <motion.div
        className="grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-4"
        initial="hidden"
        animate="show"
        variants={{ hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.05 } } }}
      >
        {options.map((opt) => (
          <motion.div key={opt.key} variants={{ hidden: { opacity: 0, scale: 0.98 }, show: { opacity: 1, scale: 1 } }}>
            <OptionCard
              selected={value === opt.key}
              title={`${opt.score} — ${opt.title}`}
              subtitle={opt.desc}
              scoreLabel={`${opt.score} pt${opt.score !== 1 ? "s" : ""}`}
              icon={opt.icon}
              onClick={() => onChange(opt.key)}
            />
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}

export function ScaleStepMulti({
  stepTitle,
  stepDesc,
  options,
  values,
  onToggle,
}: {
  stepTitle: ReactNode;
  stepDesc?: ReactNode;
  options: MultiOption[];
  values: Set<string>;
  onToggle: (key: string) => void; // alterna selección
}) {
  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-2xl font-semibold tracking-tight">{stepTitle}</h2>
        {stepDesc && <p className="text-slate-600 dark:text-slate-300">{stepDesc}</p>}
      </div>

      <motion.div
        className="grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3"
        initial="hidden"
        animate="show"
        variants={{ hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.05 } } }}
      >
        {options.map((opt) => {
          const selected = values.has(opt.key);
          return (
            <motion.div key={opt.key} variants={{ hidden: { opacity: 0, scale: 0.98 }, show: { opacity: 1, scale: 1 } }}>
              <OptionCard
                selected={selected}
                title={opt.title}
                subtitle={`${opt.desc ?? ""}${opt.desc ? " — " : ""}+${opt.score} pt`}
                scoreLabel={`+${opt.score}`}
                icon={opt.icon}
                onClick={() => onToggle(opt.key)}
              />
            </motion.div>
          );
        })}
      </motion.div>
    </div>
  );
}