/* @tweakable Header container padding classes (applied to the <header>) */
const HEADER_PADDING = "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4";

/* @tweakable Path to header logo image (relative to project root) */
const HEADER_LOGO_SRC = "logo app.png";
/* @tweakable Header logo size in pixels */
const HEADER_LOGO_SIZE_PX = 56;

/* @tweakable Visually hidden text for accessibility (logo alt/title) */
const BRAND_LABEL = "CareScale — evaluador de escalas clínicas";

import React from "react";
import ThemeToggle from "./ThemeToggle";

export function Header() {
  return (
    <header className={`${HEADER_PADDING} flex items-center justify-between`} role="banner" aria-label="Cabecera principal">
      <div className="brand" aria-hidden="false" title={BRAND_LABEL} style={{ display: "flex", gap: 12, alignItems: "center" }}>
        <div className="logo" aria-hidden="true">
          <img src={HEADER_LOGO_SRC} alt="CareScale" width={HEADER_LOGO_SIZE_PX} height={HEADER_LOGO_SIZE_PX} style={{ borderRadius: 999, objectFit: "cover" }} />
        </div>
        <div>
          <div className="title">CareScale</div>
          <div className="subtitle">Evaluaciones clínicas</div>
        </div>
      </div>

      <div>
        <ThemeToggle />
      </div>
    </header>
  );
}