
```typescript
/* @tweakable Small card used for options; visual appearance can be tuned via tailwind classes below */
import { Check } from "lucide-react";
import clsx from "clsx";
import { ReactNode } from "react";

export function OptionCard({
  selected,
  disabled,
  title,
  subtitle,
  scoreLabel,
  icon,
  onClick,
}: {
  selected?: boolean;
  disabled?: boolean;
  title: string;
  subtitle?: string;
  scoreLabel?: string;
  icon?: ReactNode;
  onClick?: () => void;
}) {
  return (
    <label
      onClick={disabled ? undefined : onClick}
      className={clsx(
        "group relative cursor-pointer rounded-2xl p-4 transition-all duration-300",
        "bg-white/70 dark:bg-slate-900/60 backdrop-blur-md ring-1 shadow-xl",
        "ring-slate-200/60 dark:ring-slate-700/60 hover:shadow-2xl hover:-translate-y-0.5",
        selected && "bg-gradient-to-br from-sky-500 to-emerald-500 text-white ring-0 shadow-2xl",
        disabled && "opacity-60 cursor-not-allowed"
      )}
    >
      {scoreLabel && (
        <span
          className={clsx(
            "absolute top-3 left-3 text-xs font-semibold px-2 py-1 rounded-full",
            "bg-sky-100 text-sky-700 dark:bg-sky-900/60 dark:text-sky-200",
            selected && "bg-white/20 text-white"
          )}
        >
          {scoreLabel}
        </span>
      )}

      <div className="flex items-start gap-3">
        {icon && <span className={clsx("h-5 w-5", selected ? "text-white/90" : "text-sky-600 dark:text-sky-400")}>{icon}</span>}
        <div>
          <div className="font-medium leading-snug">{title}</div>
          {subtitle && (
            <div className={clsx("text-sm mt-0.5", selected ? "text-white/90" : "text-slate-600 dark:text-slate-300")}>
              {subtitle}
            </div>
          )}
        </div>
      </div>

      {selected && <Check className="absolute top-3 right-3 h-5 w-5 text-white" />}
    </label>
  );
}