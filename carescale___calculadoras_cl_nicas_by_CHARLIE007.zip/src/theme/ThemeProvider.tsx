import React, { createContext, useContext, useEffect, useState } from 'react';

/* @tweakable Default theme used on first load when no saved preference is found ('light'|'dark') */
const DEFAULT_THEME: 'light' | 'dark' = 'light';
/* @tweakable LocalStorage key used for theme persistence */
const THEME_STORAGE_KEY = 'carescale-theme';

type Theme = 'light' | 'dark';
type Ctx = { theme: Theme; toggle: () => void; setTheme: (t: Theme) => void };

const ThemeCtx = createContext<Ctx>({ theme: DEFAULT_THEME, toggle: () => {}, setTheme: () => {} });

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>(DEFAULT_THEME);

  useEffect(() => {
    // Sync inicial (coincide con el script del <head>)
    try {
      const saved = localStorage.getItem(THEME_STORAGE_KEY) as Theme | null;
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      setTheme(saved ?? (prefersDark ? 'dark' : DEFAULT_THEME));
    } catch (e) {
      setTheme(DEFAULT_THEME);
    }
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') root.classList.add('dark');
    else root.classList.remove('dark');
    try {
      localStorage.setItem(THEME_STORAGE_KEY, theme);
    } catch (_) {}
  }, [theme]);

  const toggle = () => setTheme((t) => (t === 'dark' ? 'light' : 'dark'));

  return <ThemeCtx.Provider value={{ theme, toggle, setTheme }}>{children}</ThemeCtx.Provider>;
}

export const useTheme = () => useContext(ThemeCtx);