// Scales definitions (ES - es-CO). No PHI. Export simple objects.
export const BRADEN = {
  key: "BRADEN",
  title: "Escala de Braden",
  desc: "Evaluación del riesgo de úlceras por presión (6 ítems).",
  items: [
    { key: "sensoria", title: "Percepción sensorial", desc: "Evalúa respuesta a molestias por presión.",
      options:[
        {label:"1 — Completamente limitada", score:1, help:"No responde a estímulos por dolor o incomodidad."},
        {label:"2 — Muy limitada", score:2, help:"Responde solo a estímulos fuertes."},
        {label:"3 — Levemente limitada", score:3, help:"Responde a la mayoría de estímulos, con algunas ausencias."},
        {label:"4 — Sin limitación", score:4, help:"Percibe y responde normalmente."}
      ]},
    { key: "humedad", title: "Humedad", desc: "Evalúa maceración y exposición de la piel.",
      options:[
        {label:"1 — Constantemente húmeda", score:1, help:"Maceración continua, incontinencia frecuente."},
        {label:"2 — Muy húmeda", score:2, help:"Humedad frecuente durante el día."},
        {label:"3 — Ocasionalmente húmeda", score:3, help:"Episodios esporádicos."},
        {label:"4 — Raramente húmeda", score:4, help:"Piel habitualmente seca."}
      ]},
    { key: "actividad", title: "Actividad", desc: "Nivel de deambulación.",
      options:[
        {label:"1 — Encamado", score:1, help:"Inmovilidad en cama."},
        {label:"2 — Sillón", score:2, help:"Sedestación prolongada."},
        {label:"3 — Camina ocasionalmente", score:3, help:"Deambula de forma limitada."},
        {label:"4 — Camina frecuentemente", score:4, help:"Movilidad activa."}
      ]},
    { key: "movilidad", title: "Movilidad", desc: "Capacidad de cambiar y mantener posición.",
      options:[
        {label:"1 — Inmóvil", score:1, help:"No cambia la posición sin asistencia."},
        {label:"2 — Muy limitada", score:2, help:"Cambios poco efectivos."},
        {label:"3 — Levemente limitada", score:3, help:"Algunos cambios espontáneos."},
        {label:"4 — Sin limitación", score:4, help:"Cambia y mantiene postura con facilidad."}
      ]},
    { key: "nutricion", title: "Nutrición", desc: "Ingesta y aporte nutricional.",
      options:[
        {label:"1 — Muy pobre", score:1, help:"Ingesta insuficiente, pérdida de peso."},
        {label:"2 — Probablemente inadecuada", score:2, help:"Ingreso parcial, riesgo de déficit."},
        {label:"3 — Adecuada", score:3, help:"Cubre requisitos básicos."},
        {label:"4 — Excelente", score:4, help:"Óptima ingesta y estado."}
      ]},
    { key: "friccion", title: "Fricción / Cizallamiento", desc: "Evalúa efecto del deslizamiento en piel.",
      options:[
        {label:"1 — Problema", score:1, help:"Deslizamientos frecuentes y daño potencial."},
        {label:"2 — Problema potencial", score:2, help:"Riesgo intermitente de cizallamiento."},
        {label:"3 — Sin problema aparente", score:3, help:"Manejo y movilidad adecuados."}
      ]}
  ],
  computeTotal: (d)=> (d.sensoria||0)+(d.humedad||0)+(d.actividad||0)+(d.movilidad||0)+(d.nutricion||0)+(d.friccion||0),
  classify: (t)=>{
    if(t<=9) return {level:"very_high", label:"Riesgo muy alto"};
    if(t<=12) return {level:"high", label:"Riesgo alto"};
    if(t<=14) return {level:"moderate", label:"Riesgo moderado"};
    if(t<=18) return {level:"low", label:"Riesgo bajo"};
    return {level:"none", label:"Sin riesgo"};
  },
  recommendations: {
    "very_high":"Medidas inmediatas: reposicionamiento frecuente, superficies especiales, control nutricional y cuidado de la piel.",
    "high":"Reevaluación y medidas preventivas: cambio postural, superficies de apoyo, higiene de la piel.",
    "moderate":"Prevención dirigida: supervisión, cuidado de la piel y atención nutricional.",
    "low":"Continuar con cuidados habituales y monitorizar.",
    "none":"Bajo riesgo; mantener prevención estándar."
  }
};

export const DOWNTON = {
  key:"DOWNTON",
  title:"Índice de Caídas de Downton",
  desc:"Escala que suma factores de riesgo de caídas. Un puntaje ≥3 sugiere riesgo.",
  items:[
    {key:"previas", title:"Caídas previas (último año)", desc:"Antecedente predictor de nueva caída.", options:[
      {label:"No", score:0, help:"Sin caídas en el último año."},
      {label:"Sí", score:1, help:"Al menos una caída en el último año."}
    ]},
    {key:"medicacion", title:"Medicación de riesgo", desc:"Clases de fármacos que aumentan riesgo.",
      options:[
        {label:"Ninguna relevante", score:0, help:"No hay medicamentos de riesgo."},
        {label:"1 clase presente", score:1, help:"Ej: benzodiacepinas/antidepresivos/antipsicóticos/diuréticos/antihipertensivos/antiparkinsonianos"},
        {label:"≥2 clases", score:2, help:"Múltiples fármacos con potencial sinérgico."}
      ]},
    {key:"vision", title:"Déficit visual", desc:"Alteración visual que afecta seguridad.",
      options:[{label:"No",score:0,help:"Visión adecuada para actividades."},{label:"Sí",score:1,help:"Alteración visual significativa."}]},
    {key:"audicion", title:"Déficit auditivo", desc:"Alteración auditiva que afecta alerta/orientación.",
      options:[{label:"No",score:0,help:"Audición adecuada."},{label:"Sí",score:1,help:"Déficit auditivo que afecta seguridad."}]},
    {key:"mental", title:"Estado mental", desc:"Confusión o desorientación.",
      options:[{label:"Orientado",score:0,help:"Sin confusión."},{label:"Confusión/desorientación",score:1,help:"Deterioro cognitivo o delirium."}]},
    {key:"marcha", title:"Marcha", desc:"Estabilidad y uso de ayuda técnica.",
      options:[{label:"Segura",score:0,help:"Marcha estable sin ayudas."},{label:"Insegura / usa ayuda",score:1,help:"Inestabilidad evidente o uso de bastón/andador."}]}
  ],
  computeTotal:(d)=> Object.values(d).reduce((a,b)=>a+(b||0),0),
  classify:(t)=> t>=3?{level:"high",label:"Riesgo de caída"}:{level:"low",label:"Sin/bajo riesgo"},
  recommendations:{
    high:"Revisión farmacológica, ajuste ambiental, supervisión y medidas preventivas.",
    low:"Mantener controles y ambiente seguro."
  }
};

export const GCS = {
  key:"GCS",
  /** @tweakable [GCS title shown across the UI] */ 
  title:"Escala de Coma de Glasgow",
  desc:"Evaluación rápida del nivel de conciencia (3 componentes: ocular, verbal, motora).",
  items:[
    {key:"eye", title:"Ocular (E)", desc:"Apertura ocular ante estímulos.",
      options:[
        {label:"4 — Espontánea", score:4, help:"Abre los ojos sin estímulo."},
        {label:"3 — A la voz", score:3, help:"Abre a estímulo verbal."},
        {label:"2 — Al dolor", score:2, help:"Respuesta solo a estímulo doloroso."},
        {label:"1 — Ninguna", score:1, help:"Sin apertura ocular."}
      ]},
    {key:"verbal", title:"Verbal (V)", desc:"Respuesta verbal y orientación.",
      options:[
        {label:"5 — Orientado", score:5, help:"Coherente y orientado."},
        {label:"4 — Confuso", score:4, help:"Conversación desorganizada."},
        {label:"3 — Palabras inapropiadas", score:3, help:"Respuestas inadecuadas."},
        {label:"2 — Sonidos incomprensibles", score:2, help:"Sonidos sin palabras claras."},
        {label:"1 — Ninguna", score:1, help:"Sin respuesta verbal."}
      ]},
    {key:"motor", title:"Motora (M)", desc:"Respuesta motora a órdenes/estímulos.",
      options:[
        {label:"6 — Obedece órdenes", score:6, help:"Responde a órdenes simples."},
        {label:"5 — Localiza dolor", score:5, help:"Localiza y aparta estímulo doloroso."},
        {label:"4 — Retira ante dolor", score:4, help:"Retirada flexora al dolor."},
        {label:"3 — Flexión anormal", score:3, help:"Decorticación."},
        {label:"2 — Extensión anormal", score:2, help:"Desviación extensora (descerebración)."},
        {label:"1 — Ninguna", score:1, help:"Sin respuesta motora."}
      ]}
  ],
  computeTotal:(d)=> (d.eye||0)+(d.verbal||0)+(d.motor||0),
  classify:(t)=> {
    if(t<=8) return {level:"high", label:"Grave (3–8)"};
    if(t<=12) return {level:"moderate", label:"Moderada (9–12)"};
    return {level:"low", label:"Leve (13–15)"};
  },
  recommendations:{
    high:"Vigilancia intensiva, control de vía aérea y considerar derivación según protocolo.",
    moderate:"Monitorización neurológica y valoración por equipo especializado.",
    low:"Observación y evaluación según evolución clínica."
  }
};