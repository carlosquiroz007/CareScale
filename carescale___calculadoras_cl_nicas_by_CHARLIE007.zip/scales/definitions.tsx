
```typescript
/* @tweakable Colors used for classification badges */
import { Eye, Volume2, Hand, Activity, Droplets, Utensils, MoveRight, Footprints, Glasses, HearingAid, Pill, Brain } from "lucide-react";

export type ScaleKey = "BRADEN" | "DOWNTON" | "GCS";

export type StepSingle = {
  kind: "single";
  key: string;
  title: string;
  desc?: string;
  options: { key: string; title: string; desc?: string; score: number; icon?: JSX.Element }[];
};

export type StepMulti = {
  kind: "multi";
  key: string;
  title: string;
  desc?: string;
  options: { key: string; title: string; desc?: string; score: number; icon?: JSX.Element }[];
};

export type Step = StepSingle | StepMulti;

export type ScaleDefinition = {
  key: ScaleKey;
  title: string;
  hero?: string;
  steps: Step[];
  computeTotal: (answers: Record<string, number | number[]>) => number;
  classify: (total: number) => { label: string; color: string };
};

/* @tweakable Path to image that replaces the literal "E" in the GCS ocular step title */
const GCS_E_ICON_SRC = "d815bfe7-9762-4dd6-a29e-4e35457594e0.png";
/* @tweakable Size in pixels for the 'E' replacement icon shown in the GCS ocular step title */
const GCS_E_ICON_SIZE_PX = 20;

// =============== BRADEN =================
export const BradenDef: ScaleDefinition = {
  key: "BRADEN",
  title: "Escala de Braden",
  hero: "Evaluación del riesgo de úlceras por presión (6 ítems).",
  steps: [
    {
      kind: "single",
      key: "sensorial",
      title: "Percepción sensorial (1–4)",
      desc: "Capacidad para responder a la incomodidad por presión.",
      options: [
        { key: "1", title: "Completamente limitada", desc: "No responde al dolor", score: 1, icon: <Activity /> },
        { key: "2", title: "Muy limitada", desc: "Respuesta muy reducida", score: 2, icon: <Activity /> },
        { key: "3", title: "Levemente limitada", desc: "Responde de forma inconsistente", score: 3, icon: <Activity /> },
        { key: "4", title: "Sin limitación", desc: "Percibe y responde normalmente", score: 4, icon: <Activity /> },
      ],
    },
    {
      kind: "single",
      key: "humedad",
      title: "Humedad (1–4)",
      desc: "Exposición de la piel a la humedad.",
      options: [
        { key: "1", title: "Constantemente húmeda", score: 1, icon: <Droplets /> },
        { key: "2", title: "Muy húmeda", score: 2, icon: <Droplets /> },
        { key: "3", title: "Ocasionalmente húmeda", score: 3, icon: <Droplets /> },
        { key: "4", title: "Raramente húmeda", score: 4, icon: <Droplets /> },
      ],
    },
    {
      kind: "single",
      key: "actividad",
      title: "Actividad (1–4)",
      desc: "Grado de movilidad diaria.",
      options: [
        { key: "1", title: "Encamado", score: 1, icon: <MoveRight /> },
        { key: "2", title: "Sillón", score: 2, icon: <MoveRight /> },
        { key: "3", title: "Camina ocasionalmente", score: 3, icon: <MoveRight /> },
        { key: "4", title: "Camina frecuentemente", score: 4, icon: <MoveRight /> },
      ],
    },
    {
      kind: "single",
      key: "movilidad",
      title: "Movilidad (1–4)",
      options: [
        { key: "1", title: "Inmóvil", score: 1, icon: <Hand /> },
        { key: "2", title: "Muy limitada", score: 2, icon: <Hand /> },
        { key: "3", title: "Levemente limitada", score: 3, icon: <Hand /> },
        { key: "4", title: "Sin limitación", score: 4, icon: <Hand /> },
      ],
    },
    {
      kind: "single",
      key: "nutricion",
      title: "Nutrición (1–4)",
      options: [
        { key: "1", title: "Muy pobre", score: 1, icon: <Utensils /> },
        { key: "2", title: "Probablemente inadecuada", score: 2, icon: <Utensils /> },
        { key: "3", title: "Adecuada", score: 3, icon: <Utensils /> },
        { key: "4", title: "Excelente", score: 4, icon: <Utensils /> },
      ],
    },
    {
      kind: "single",
      key: "friccion",
      title: "Fricción/Cizallamiento (1–3)",
      options: [
        { key: "1", title: "Problema", score: 1, icon: <Footprints /> },
        { key: "2", title: "Problema potencial", score: 2, icon: <Footprints /> },
        { key: "3", title: "Sin problema aparente", score: 3, icon: <Footprints /> },
      ],
    },
  ],
  computeTotal: (a) =>
    Number(a.sensorial ?? 0) +
    Number(a.humedad ?? 0) +
    Number(a.actividad ?? 0) +
    Number(a.movilidad ?? 0) +
    Number(a.nutricion ?? 0) +
    Number(a.friccion ?? 0),
  classify: (t) => {
    if (t <= 9) return { label: "Riesgo muy alto", color: "#ef4444" };
    if (t <= 12) return { label: "Riesgo alto", color: "#f97316" };
    if (t <= 14) return { label: "Riesgo moderado", color: "#f59e0b" };
    if (t <= 18) return { label: "Riesgo bajo", color: "#10b981" };
    return { label: "Sin riesgo", color: "#22c55e" };
  },
};

// =============== DOWNTON =================
/* @tweakable Threshold for Downton high risk: scores >= this value will be classified as 'high' */
const DOWNTON_HIGH_THRESHOLD = 3;

export const DowntonDef: ScaleDefinition = {
  key: "DOWNTON",
  title: "Índice de Caídas de Downton",
  hero: "Suma factores de riesgo de caídas (umbral ≥3).",
  steps: [
    {
      kind: "single",
      key: "caidas_previas",
      title: "Caídas previas (último año)",
      options: [
        { key: "0", title: "No", score: 0, icon: <Activity /> },
        { key: "1", title: "Sí (≥1)", score: 1, icon: <Activity /> },
      ],
    },
    {
      kind: "multi",
      key: "medicacion",
      title: "Medicación asociada a riesgo (marca todas las que apliquen)",
      options: [
        { key: "benzo", title: "Benzodiacepinas", score: 1, icon: <Pill /> },
        { key: "antidep", title: "Antidepresivos", score: 1, icon: <Pill /> },
        { key: "antipsi", title: "Antipsicóticos", score: 1, icon: <Pill /> },
        { key: "diuret", title: "Diuréticos", score: 1, icon: <Pill /> },
        { key: "antiht", title: "Antihipertensivos", score: 1, icon: <Pill /> },
        { key: "antipark", title: "Antiparkinsonianos", score: 1, icon: <Pill /> },
      ],
    },
    {
      kind: "multi",
      key: "deficit_sensorial",
      title: "Déficit sensorial",
      options: [
        { key: "visual", title: "Visual", score: 1, icon: <Glasses /> },
        { key: "auditivo", title: "Auditivo", score: 1, icon: <HearingAid /> },
      ],
    },
    {
      kind: "single",
      key: "estado_mental",
      title: "Estado mental",
      options: [
        { key: "0", title: "Orientado", score: 0, icon: <Brain /> },
        { key: "1", title: "Confusión/Desorientación", score: 1, icon: <Brain /> },
      ],
    },
    {
      kind: "single",
      key: "marcha",
      title: "Marcha/Deambulación",
      options: [
        { key: "0", title: "Segura, sin ayuda técnica", score: 0, icon: <Footprints /> },
        { key: "1", title: "Insegura o usa ayuda técnica", score: 1, icon: <Footprints /> },
      ],
    },
  ],
  computeTotal: (a) => {
    const meds = (a.medicacion as number[])?.reduce((s, n) => s + (Number(n) || 0), 0) ?? 0;
    const sens = (a.deficit_sensorial as number[])?.reduce((s, n) => s + (Number(n) || 0), 0) ?? 0;
    return (
      Number(a.caidas_previas ?? 0) + meds + sens + Number(a.estado_mental ?? 0) + Number(a.marcha ?? 0)
    );
  },
  /* @tweakable Provide a 'level' string so result rendering can show a badge/class (values: 'high'|'low') */
  classify: (t) =>
    t >= DOWNTON_HIGH_THRESHOLD
      ? { level: "high", label: "Riesgo de caída", color: "#f97316" }
      : { level: "low", label: "Sin/bajo riesgo", color: "#10b981" },
};

// =============== GCS =================
export const GCSDef: ScaleDefinition = {
  key: "GCS",
  /** @tweakable [GCS title shown across the UI] */
  title: "Escala de Coma de Glasgow",
  hero: "Evalúa apertura ocular, respuesta verbal y motora.",
  steps: [
    {
      kind: "single",
      key: "eye",
      // @ts-ignore allow React node in title so we can embed an image for the "E" label
      title: (
        <>
          1. Ocular&nbsp;
          <img src={GCS_E_ICON_SRC} alt="E" style={{ width: GCS_E_ICON_SIZE_PX, height: GCS_E_ICON_SIZE_PX, verticalAlign: "middle" }} />
        </>
      ),
      desc: "Apertura ocular ante estímulos.",
      options: [
        { key: "4", title: "Espontánea", desc: "Abre sin estímulo", score: 4, icon: <Eye /> },
        { key: "3", title: "A la voz", desc: "Abre a estímulo verbal", score: 3, icon: <Eye /> },
        { key: "2", title: "Al dolor", desc: "Solo con dolor", score: 2, icon: <Eye /> },
        { key: "1", title: "Ninguna", desc: "Sin apertura", score: 1, icon: <Eye /> },
      ],
    },
    {
      kind: "single",
      key: "verbal",
      title: "2. Verbal (V)",
      options: [
        { key: "5", title: "Orientado", score: 5, icon: <Volume2 /> },
        { key: "4", title: "Confuso", score: 4, icon: <Volume2 /> },
        { key: "3", title: "Palabras inapropiadas", score: 3, icon: <Volume2 /> },
        { key: "2", title: "Sonidos incomprensibles", score: 2, icon: <Volume2 /> },
        { key: "1", title: "Ninguna", score: 1, icon: <Volume2 /> },
      ],
    },
    {
      kind: "single",
      key: "motor",
      title: "3. Motora (M)",
      options: [
        { key: "6", title: "Obedece órdenes", score: 6, icon: <Hand /> },
        { key: "5", title: "Localiza dolor", score: 5, icon: <Hand /> },
        { key: "4", title: "Retira ante dolor", score: 4, icon: <Hand /> },
        { key: "3", title: "Flexión anormal", score: 3, icon: <Hand /> },
        { key: "2", title: "Extensión anormal", score: 2, icon: <Hand /> },
        { key: "1", title: "Ninguna", score: 1, icon: <Hand /> },
      ],
    },
  ],
  computeTotal: (a) => Number(a.eye ?? 0) + Number(a.verbal ?? 0) + Number(a.motor ?? 0),
  classify: (t) => {
    if (t <= 8) return { label: "Grave (3–8)", color: "#ef4444" };
    if (t <= 12) return { label: "Moderada (9–12)", color: "#f59e0b" };
    return { label: "Leve (13–15)", color: "#10b981" };
  },
};